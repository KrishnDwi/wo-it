<?php

namespace App\Imports;

use App\Models\Department;
use App\Models\Employee;
use App\Models\TrainingModule;
use App\Models\TrainingHistory;
use Carbon\Carbon;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;

/**
 * Import satu sheet (Staff / DW / Casual / Trainee / Outsourcing).
 *
 * PENTING: sengaja TIDAK pakai WithHeadingRow, karena baris header di file
 * HR asli Anda posisinya BERBEDA-BEDA per sheet (Staff = baris 3, sheet
 * lain = baris 2 — ada baris banner/kosong di atasnya). Sebagai gantinya,
 * kelas ini SCAN beberapa baris pertama untuk menemukan baris yang memuat
 * "ID No." dan "Full Name", baru dari situ membangun peta kolom. Ini bikin
 * import tahan terhadap perbedaan jumlah baris banner/kosong di atas header,
 * tanpa perlu tahu persis di baris ke berapa header berada.
 *
 * Kolom lain dicari dengan fragment matching (case-insensitive, substring)
 * karena penamaan kolom tidak 100% konsisten antar sheet (mis. "Joining
 * Date Hotel" di Staff vs "Join Date" di Casual, "Position" vs
 * "Current Position", dst).
 */
class EmployeeSheetImport implements ToCollection
{
    public array $errors = [];
    public int $processedCount = 0;
    public int $skippedBlankRows = 0;

    public function __construct(protected string $employeeType)
    {
    }

    public function collection(Collection $rows)
    {
        $rows = $rows->values();

        $headerRowIndex = $this->findHeaderRowIndex($rows);

        if ($headerRowIndex === null) {
            $this->errors[] = 'Baris header ("ID No." + "Full Name") tidak ditemukan di sheet ini — sheet dilewati sepenuhnya.';
            return;
        }

        // colIndex => header text (lowercased, trimmed) — dipakai untuk fragment matching
        $headerMap = [];
        foreach ($rows[$headerRowIndex]->toArray() as $colIndex => $cellValue) {
            $text = strtolower(trim((string) $cellValue));
            if ($text !== '') {
                $headerMap[$colIndex] = $text;
            }
        }

        for ($i = $headerRowIndex + 1; $i < $rows->count(); $i++) {
            $rowNumber = $i + 1; // perkiraan nomor baris Excel (cukup untuk penanda di pesan error)
            $rawRow = $rows[$i]->toArray();

            // Susun assoc array: header_text => value, berdasarkan posisi kolom yang sama
            $data = [];
            foreach ($headerMap as $colIndex => $headerText) {
                $data[$headerText] = $rawRow[$colIndex] ?? null;
            }

            // Baris kosong total (banyak terjadi di file asli sebagai pemisah antar departemen) — lewati diam-diam
            if (collect($data)->filter(fn ($v) => $v !== null && $v !== '')->isEmpty()) {
                $this->skippedBlankRows++;
                continue;
            }

            try {
                $employee = $this->upsertEmployee($data, $rowNumber);

                if (!$employee) {
                    continue;
                }

                $this->processCertification(
                    data: $data,
                    employee: $employee,
                    moduleCode: 'CERT-FOOD',
                    dateFragments: ['sertifikasi', 'makanan'],
                    expiredFragments: null
                );

                $this->processCertification(
                    data: $data,
                    employee: $employee,
                    moduleCode: 'CERT-KOMP',
                    dateFragments: ['date', 'kompe'], // "Dateserifikasi Kompetensi" — HARUS ada 'date' agar tidak nyasar ke kolom nama LSP/posisi yang juga mengandung "kompeten(si)"
                    expiredFragments: ['expired', 'kompe']
                );

                $this->processedCount++;
            } catch (\Throwable $e) {
                $this->errors[] = "Baris {$rowNumber}: {$e->getMessage()}";
            }
        }
    }

    /**
     * Scan 10 baris pertama untuk menemukan baris yang mengandung
     * "id no" DAN "full name" di antara nilai selnya — itulah baris header.
     */
    protected function findHeaderRowIndex(Collection $rows): ?int
    {
        $limit = min(10, $rows->count());

        for ($i = 0; $i < $limit; $i++) {
            $joined = strtolower(implode(' ', array_map(
                fn ($v) => (string) $v,
                $rows[$i]->toArray()
            )));

            if (str_contains($joined, 'id no') && str_contains($joined, 'full name')) {
                return $i;
            }
        }

        return null;
    }

    protected function upsertEmployee(array $data, int $rowNumber): ?Employee
    {
        // "ID No." dipakai sebagai identifier unik (BUKAN kolom "NIK" asli yang
        // menyimpan Nomor Induk Kependudukan KTP — itu data sensitif yang
        // sengaja tidak kita simpan di ETMS, sesuai kesepakatan sebelumnya).
        $employeeIdNo = $this->findValue($data, ['id', 'no']);
        $name = $this->findValue($data, ['full', 'name']);
        $departmentName = $this->findValue($data, ['department']);

        if (empty($employeeIdNo) || empty($name)) {
            $this->errors[] = "Baris {$rowNumber}: dilewati — kolom ID No. atau Full Name kosong.";
            return null;
        }

        if (empty($departmentName)) {
            $this->errors[] = "Baris {$rowNumber}: dilewati — kolom Department kosong.";
            return null;
        }

        $department = $this->findOrCreateDepartment($departmentName);

        $position = $this->findValue($data, ['current', 'position']) ?? $this->findValue($data, ['position']);
        $joinDate = $this->parseDate($this->findValue($data, ['join', 'date']));

        // "Resign date" terisi adalah sinyal yang jauh lebih akurat ketimbang
        // menebak dari teks "Employee Status" (yang di data Anda ternyata berisi
        // gabungan status+gender, mis. "Permanent Male", "Contract Female").
        $resignDate = $this->parseDate($this->findValue($data, ['resign', 'date']));
        $statusRaw = strtolower((string) $this->findValue($data, ['employee', 'status']));
        $employmentStatus = $resignDate
            ? 'resigned'
            : (str_contains($statusRaw, 'inactive') || str_contains($statusRaw, 'non')
                ? 'inactive'
                : 'active');

        $phone = $this->findValue($data, ['mobile']);
        $email = $this->findValue($data, ['email']);

        return Employee::updateOrCreate(
            ['nik' => trim((string) $employeeIdNo)],
            [
                'name' => trim($name),
                'department_id' => $department->id,
                'position' => $position,
                'join_date' => $joinDate,
                'employment_status' => $employmentStatus,
                'employee_type' => $this->employeeType,
                'email' => $email,
                'phone' => $phone ? (string) $phone : null,
            ]
        );
    }

    /** @var \Illuminate\Support\Collection|null Cache departemen untuk hindari query berulang per baris */
    protected ?Collection $departmentCache = null;

    /**
     * Cari departemen dengan normalisasi (buang spasi & simbol, lowercase)
     * sebelum membuat baru — supaya "F & B Product" dan "FB Product" (atau
     * "Front office" vs "Front Office") dianggap departemen yang SAMA.
     * Ini terbukti perlu dari data riil Anda: kedua variasi ejaan itu memang
     * muncul di sheet berbeda untuk departemen yang sama.
     *
     * CATATAN: ini hanya menyatukan variasi spasi/simbol/huruf besar-kecil.
     * Nama yang benar-benar berbeda kata (mis. "P&C" vs "Human Resources")
     * TETAP dianggap departemen terpisah — sistem tidak menebak sejauh itu.
     */
    protected function findOrCreateDepartment(string $name): Department
    {
        $trimmed = trim($name);
        $normalizedTarget = $this->normalizeDeptKey($trimmed);

        if ($this->departmentCache === null) {
            $this->departmentCache = Department::all();
        }

        $existing = $this->departmentCache->first(
            fn ($d) => $this->normalizeDeptKey($d->name) === $normalizedTarget
        );

        if ($existing) {
            return $existing;
        }

        $created = Department::create(['name' => $trimmed, 'is_active' => true]);
        $this->departmentCache->push($created);

        return $created;
    }

    protected function normalizeDeptKey(string $name): string
    {
        return strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $name));
    }

    /**
     * Membuat/memperbarui TrainingHistory dari kolom sertifikasi eksternal.
     * training_participant_id sengaja NULL karena sertifikasi ini didapat
     * di luar Training Session internal (nullable sejak desain Tahap 3).
     */
    protected function processCertification(
        array $data,
        Employee $employee,
        string $moduleCode,
        array $dateFragments,
        ?array $expiredFragments
    ): void {
        $certDate = $this->parseDate($this->findValue($data, $dateFragments));

        if (!$certDate) {
            return; // tidak ada data sertifikasi di baris ini — lewati diam-diam
        }

        $module = TrainingModule::where('code', $moduleCode)->first();

        if (!$module) {
            $this->errors[] = "Modul {$moduleCode} tidak ditemukan di Master Training — jalankan TrainingModuleSeeder terlebih dahulu.";
            return;
        }

        $expiredAt = $expiredFragments
            ? $this->parseDate($this->findValue($data, $expiredFragments))
            : null;

        if (!$expiredAt && $module->validity_months) {
            $expiredAt = Carbon::parse($certDate)->addMonths($module->validity_months)->format('Y-m-d');
        }

        TrainingHistory::updateOrCreate(
            [
                'employee_id' => $employee->id,
                'training_module_id' => $module->id,
                'training_date' => $certDate,
            ],
            [
                'training_participant_id' => null,
                'training_code_snapshot' => $module->code,
                'training_name_snapshot' => $module->name,
                'is_mandatory_snapshot' => $module->is_mandatory,
                'trainer_name_snapshot' => 'Sertifikasi Eksternal (Import Excel)',
                'duration_hours_snapshot' => $module->standard_duration_hours,
                'validity_months_snapshot' => $module->validity_months,
                'expired_at' => $expiredAt,
            ]
        );
    }

    /**
     * Cari value berdasarkan fragment (substring, case-insensitive) di
     * header — bukan nama kolom persis. Contoh: fragments ['current','position']
     * akan cocok dengan header "Current Position".
     */
    protected function findValue(array $data, array $fragments): ?string
    {
        foreach ($data as $headerText => $value) {
            if ($value === null || $value === '') {
                continue;
            }

            $matchesAll = true;
            foreach ($fragments as $fragment) {
                if (!str_contains($headerText, $fragment)) {
                    $matchesAll = false;
                    break;
                }
            }

            if ($matchesAll) {
                return (string) $value;
            }
        }

        return null;
    }

    protected function parseDate($value): ?string
    {
        if (empty($value)) {
            return null;
        }

        if (is_numeric($value)) {
            try {
                return \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($value)->format('Y-m-d');
            } catch (\Throwable $e) {
                return null;
            }
        }

        try {
            return Carbon::parse($value)->format('Y-m-d');
        } catch (\Throwable $e) {
            return null;
        }
    }
}
